import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-retailer-accept-order',
  templateUrl: './retailer-accept-order.component.html',
  styleUrls: ['./retailer-accept-order.component.css']
})
export class RetailerAcceptOrderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}