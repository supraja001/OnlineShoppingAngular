import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup } from '@angular/forms';
import { ApiService } from '../shared/api.service';
import { RetailerModel } from './retailer.model';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';

@Component({
  selector: 'app-retailer',
  templateUrl: './retailer.component.html',
  styleUrls: ['./retailer.component.css']
})
export class RetailerComponent implements OnInit {

  formValue !: FormGroup;
  productData !: any;
  showAdd !: boolean;
  showUpdate !: boolean;
  retailerModelObj : RetailerModel = new RetailerModel();

  constructor(private formbuilder: FormBuilder,private api:ApiService) { }

  ngOnInit(): void {
    this.formValue = this.formbuilder.group({
      productName: [''],
      productPrice: [''],
      productDescription: [''],
      brand: [''],
      warranty: [''],
      availableStocks: ['']
    })
    this.getAllProducts();
  }

  clickAddProduct(){
    this.formValue.reset();
    this.showAdd = true;
    this.showUpdate = false;
  }
 
  postProductDetails(){
    this.retailerModelObj.productName = this.formValue.value.productName;
    this.retailerModelObj.productPrice = this.formValue.value.productPrice;
    this.retailerModelObj.productDescription = this.formValue.value.productDescription;
    this.retailerModelObj.brand = this.formValue.value.brand;
    this.retailerModelObj.warranty = this.formValue.value.warranty;
    this.retailerModelObj.availableStocks = this.formValue.value.availableStocks;

    this.api.postProduct(this.retailerModelObj)
    .subscribe(res=>{
      console.log(res);
      alert("Product Added Successfully ");
      let ref = document.getElementById('cancel');
      ref?.click();
      this.formValue.reset();
      this.getAllProducts();
    },
    err=>{
      alert("Something Went Wrong");
    }
    )

  }

  getAllProducts(){
    this.api.getProduct()
    .subscribe(res=> {
      this.productData = res;
    })
  }

  deleteProduct(row:any){
    this.api.deleteProduct(row.id)
    .subscribe(res=>{
      alert("Product Deleted")
      this.getAllProducts();
    })
  }

  onEdit(row:any){
    this.showAdd = false;
    this.showUpdate = true;
    this.retailerModelObj.id = row.id;
    this.formValue.controls['productName'].setValue(row.productName);
    this.formValue.controls['productPrice'].setValue(row.productPrice);
    this.formValue.controls['productDescription'].setValue(row.productDescription);
    this.formValue.controls['brand'].setValue(row.brand);
    this.formValue.controls['warranty'].setValue(row.warranty);
    this.formValue.controls['availableStocks'].setValue(row.availableStocks);
  }
  updateProductDetails(){
    this.retailerModelObj.productName = this.formValue.value.productName;
    this.retailerModelObj.productPrice = this.formValue.value.productPrice;
    this.retailerModelObj.productDescription = this.formValue.value.productDescription;
    this.retailerModelObj.brand = this.formValue.value.brand;
    this.retailerModelObj.warranty = this.formValue.value.warranty;
    this.retailerModelObj.availableStocks = this.formValue.value.availableStocks;

    this.api.updateProduct(this.retailerModelObj,this.retailerModelObj.id)
    .subscribe(res=>{
      alert("Updated Successfully");
      let ref = document.getElementById('cancel');
      ref?.click();
      this.formValue.reset();
      this.getAllProducts(); 
    })
  }
}