import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-forgotpassword',
  templateUrl: './user-forgotpassword.component.html',
  styleUrls: ['./user-forgotpassword.component.css']
})
export class UserForgotpasswordComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
