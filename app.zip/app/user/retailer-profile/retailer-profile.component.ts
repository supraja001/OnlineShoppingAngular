import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-retailer-profile',
  templateUrl: './retailer-profile.component.html',
  styleUrls: ['./retailer-profile.component.css']
})
export class RetailerProfileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}