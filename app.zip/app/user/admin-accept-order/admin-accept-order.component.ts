import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-accept-order',
  templateUrl: './admin-accept-order.component.html',
  styleUrls: ['./admin-accept-order.component.css']
})
export class AdminAcceptOrderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
