import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-retailer-revenue',
  templateUrl: './retailer-revenue.component.html',
  styleUrls: ['./retailer-revenue.component.css']
})
export class RetailerRevenueComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}