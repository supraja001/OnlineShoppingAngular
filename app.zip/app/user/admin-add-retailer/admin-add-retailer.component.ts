import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-add-retailer',
  templateUrl: './admin-add-retailer.component.html',
  styleUrls: ['./admin-add-retailer.component.css']
})
export class AdminAddRetailerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
