import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-retailer-docs',
  templateUrl: './retailer-docs.component.html',
  styleUrls: ['./retailer-docs.component.css']
})
export class RetailerDocsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
