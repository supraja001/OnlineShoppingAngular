import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RetailerDocsComponent } from './retailer-docs.component';

describe('RetailerDocsComponent', () => {
  let component: RetailerDocsComponent;
  let fixture: ComponentFixture<RetailerDocsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RetailerDocsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RetailerDocsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
