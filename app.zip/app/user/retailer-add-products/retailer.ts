export class RetailerModel{
    id: number = 0;
    productName: string = '';
    productPrice: number = 0;
    productDescription: string = '';
    brand: string = '';
    warranty: string = '';
    availableStocks: number = 0;
}
