import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RetailerAddProductsComponent } from './retailer-add-products.component';

describe('RetailerAddProductsComponent', () => {
  let component: RetailerAddProductsComponent;
  let fixture: ComponentFixture<RetailerAddProductsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RetailerAddProductsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RetailerAddProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
