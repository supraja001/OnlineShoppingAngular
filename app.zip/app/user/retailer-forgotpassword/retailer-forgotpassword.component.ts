import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-retailer-forgotpassword',
  templateUrl: './retailer-forgotpassword.component.html',
  styleUrls: ['./retailer-forgotpassword.component.css']
})
export class RetailerForgotpasswordComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
