import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminLoginComponent } from './user/admin-login/admin-login.component';
import { LoginComponent } from './user/login/login.component';
import { RetailerDocsComponent } from './user/retailer-docs/retailer-docs.component';
import { RetailerForgotpasswordComponent } from './user/retailer-forgotpassword/retailer-forgotpassword.component';
import { RetailerLoginComponent } from './user/retailer-login/retailer-login.component';
import { RetailerRegisterComponent } from './user/retailer-register/retailer-register.component';
import { UserForgotpasswordComponent } from './user/user-forgotpassword/user-forgotpassword.component';
import { UserRegisterComponent } from './user/user-register/user-register.component';
import { WelcomeComponent } from './user/welcome/welcome.component';



const routes: Routes = [
  // {
  //   path:'**',
  //   //redirectTo:'/login',
  //   component: LoginComponent,
  //   pathMatch:'full',
  // },
  // {
  //   path:'login',
  //   //redirectTo:'/login',
  //   component: LoginComponent,
  //   pathMatch:'full',
  // },
  // {
  //   path:'app-retailer-login',
  //   //redirectTo:'/login',
  //   component: RetailerLoginComponent,
  //   pathMatch:'full',
  // },
  // {path:'cart',component:CartComponent},
  //{path:'userlogin',component:LoginComponent,pathMatch:'full'},
  //{path:'retailerlogin',component:RetailerLoginComponent},
  //{path:'adminlogin',component:AdminLoginComponent}
  {
    path:'',
    component:WelcomeComponent
  },
  {
    path:'login',
    component:LoginComponent
  },
  {
    path:'retailer-login',
    component:RetailerLoginComponent
  },
  {
    path:'admin-login',
    component:AdminLoginComponent
  },
  {
    path:'user-forgotpassword',
    component:UserForgotpasswordComponent
  },
  {
    path:'retailer-forgotpassword',
    component:RetailerForgotpasswordComponent
  },
  {
    path:'user-register',
    component:UserRegisterComponent
  },
  {
    path:'retailer-register',
    component:RetailerRegisterComponent
  },
  {
    path:'retailer-docs',
    component:RetailerDocsComponent
  },
  {
    path:'admin-profile',
    component: AdminLoginComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
