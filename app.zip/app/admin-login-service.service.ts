import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Admin } from './admin';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class AdminLoginServiceService {

  constructor(private http:HttpClient) { }

  loginAdmin(admin:Admin):Observable<boolean>{
    return this.http.post<boolean>
    ("http://localhost:9090/admin/login",admin);

  // public login(admin){
  //   return this.http.post("http://localhost:9090/admin/login",admin,{responseType:'text'});
  // }
}
}
