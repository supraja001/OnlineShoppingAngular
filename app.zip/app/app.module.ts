import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './user/home/home.component';
import { FooterComponent } from './user/footer/footer.component';
import { MyaccountComponent } from './user/myaccount/myaccount.component';
import { HomeheaderComponent } from './user/homeheader/homeheader.component';
import { CartComponent } from './user/cart/cart.component';
import { WishlistComponent } from './user/wishlist/wishlist.component';
import { CheckoutComponent } from './user/checkout/checkout.component';
import { LoginComponent } from './user/login/login.component';
import { UserRegisterComponent } from './user/user-register/user-register.component';
import { RetailerLoginComponent } from './user/retailer-login/retailer-login.component';
import { AdminLoginComponent } from './user/admin-login/admin-login.component';
import { WelcomeComponent } from './user/welcome/welcome.component';
import { UserForgotpasswordComponent } from './user/user-forgotpassword/user-forgotpassword.component';
import { RetailerForgotpasswordComponent } from './user/retailer-forgotpassword/retailer-forgotpassword.component';
import { RetailerRegisterComponent } from './user/retailer-register/retailer-register.component';
import { RetailerDocsComponent } from './user/retailer-docs/retailer-docs.component';
import { AdminAcceptOrderComponent } from './user/admin-accept-order/admin-accept-order.component';
import { RetailerAcceptOrderComponent } from './user/retailer-accept-order/retailer-accept-order.component';
import { RetailerHomeComponent } from './user/retailer-home/retailer-home.component';
import { RetailerProfileComponent } from './user/retailer-profile/retailer-profile.component';
import { RetailerRevenueComponent } from './user/retailer-revenue/retailer-revenue.component';

import { RouterModule } from '@angular/router';
import { RetailerComponent } from './user/retailer-add-products/retailer-add-products.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AdminAddRetailerComponent } from './user/admin-add-retailer/admin-add-retailer.component';
import { AdminProfileComponent } from './user/admin-profile/admin-profile.component';
import { AdminLoginServiceService } from './admin-login-service.service';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    FooterComponent,
    MyaccountComponent,
    HomeheaderComponent,
    CartComponent,
    WishlistComponent,
    CheckoutComponent,
    LoginComponent,
    UserRegisterComponent,
    RetailerLoginComponent,
    AdminLoginComponent,
    WelcomeComponent,
    UserForgotpasswordComponent,
    RetailerForgotpasswordComponent,
    RetailerRegisterComponent,
    RetailerDocsComponent,
    AdminAcceptOrderComponent,
    RetailerAcceptOrderComponent,
    RetailerHomeComponent,
    RetailerProfileComponent,
    RetailerRevenueComponent,
    RetailerComponent,
    AdminAddRetailerComponent,
    AdminProfileComponent
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule
    
  ],
  providers: [AdminLoginServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
